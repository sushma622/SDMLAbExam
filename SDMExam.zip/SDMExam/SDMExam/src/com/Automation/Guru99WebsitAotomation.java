package com.Automation;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class Guru99WebsitAotomation {
	public static void main(String[] args) throws InterruptedException {
		
	
		System.setProperty("webdriver.chrome.driver","D:\\SeleniumData\\chromedriver-win32\\chromedriver-win32\\chromedriver.exe");
	    WebDriver d1 = new ChromeDriver();
	    
	    d1.get("https://demo.guru99.com/test/newtours/index.php");
	    
	    String s1=d1.getTitle();
	    System.out.println("Current URL :- "+d1.getCurrentUrl()); 
	    
	    Thread.sleep(2000);
	    
	   d1.findElement(By.xpath("//a[contains(text(),'REGISTER')]")).click();
	
	   
	   d1.findElement(By.xpath("//tbody/tr[2]/td[2]/input[1]")).sendKeys("Sushma");
	   Thread.sleep(1000);
	   d1.findElement(By.xpath("//tbody/tr[3]/td[2]/input[1]")).sendKeys("Jadhav");
	   Thread.sleep(1000);
	   d1.findElement(By.xpath("//tbody/tr[4]/td[2]/input[1]")).sendKeys("9322245705");
	   Thread.sleep(1000);
	   d1.findElement(By.xpath("//input[@id='userName']")).sendKeys("jadhavsushma2000@gmail.com");
	   Thread.sleep(1000);
	   d1.findElement(By.xpath("//tbody/tr[7]/td[2]/input[1]")).sendKeys("Sadgurunagar Bhosari Pune-39");
	   Thread.sleep(1000);
	   d1.findElement(By.xpath("//tbody/tr[8]/td[2]/input[1]")).sendKeys("Pune");
	   Thread.sleep(1000);
	   d1.findElement(By.xpath("//tbody/tr[9]/td[2]/input[1]")).sendKeys("Maharashtra");
	   Thread.sleep(1000);
	   d1.findElement(By.xpath("//tbody/tr[10]/td[2]/input[1]")).sendKeys("411039");
	   Thread.sleep(1000);
	   
	   Select country = new Select(d1.findElement(By.xpath("//tbody/tr[11]/td[2]/select[1]")));
	   country.selectByVisibleText("MALDIVES");
	   Thread.sleep(1000);
	   
	   d1.findElement(By.xpath("//input[@id='email']")).sendKeys("Sushma123");
	   Thread.sleep(1000);
	   d1.findElement(By.xpath("//tbody/tr[14]/td[2]/input[1]")).sendKeys("Sushma@123");
	   Thread.sleep(1000);
	   d1.findElement(By.xpath("//tbody/tr[15]/td[2]/input[1]")).sendKeys("Sushma@123");
	   Thread.sleep(1000);
	   d1.findElement(By.xpath("//tbody/tr[17]/td[1]/input[1]")).click();
	
	   
	   d1.findElement(By.xpath("//a[contains(text(),'SIGN-OFF')]")).click();
	   
	   WebElement username = d1.findElement(By.xpath("//tbody/tr[2]/td[2]/input[1]"));
	   username .sendKeys("Sushma123");
	   String printusername =username.getAttribute("value");
	   System.out.println("UserName:- "+printusername);
	   Thread.sleep(1000);
	   WebElement password=d1.findElement(By.xpath("//tbody/tr[3]/td[2]/input[1]"));
	   password.sendKeys("Sushma@123");
	   String printpassword =  password.getAttribute("value");
	   System.out.println("Password:- "+printpassword);
	   d1.findElement(By.xpath("//tbody/tr[4]/td[2]/div[1]/input[1]")).click();
	   
	   
	   
	}

}
